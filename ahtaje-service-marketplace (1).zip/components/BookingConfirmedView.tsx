import React, { useEffect } from 'react';

interface BookingConfirmedViewProps {
  onFinish: () => void;
  t: {
      title: string;
      subtitle: string;
  }
}

const BookingConfirmedView: React.FC<BookingConfirmedViewProps> = ({ onFinish, t }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 4000); // Redirect after 4 seconds

    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="flex flex-col items-center justify-center text-center h-full animate-fade-in py-16">
        <svg className="w-16 h-16 text-green-600 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      <h2 className="text-2xl font-bold text-black">{t.title}</h2>
      <p className="text-gray-600 mt-2 max-w-md">
        {t.subtitle}
      </p>
    </div>
  );
};

export default BookingConfirmedView;
