import React from 'react';
import { Service, BookingDetails, Quote } from '../types';

interface QuoteViewProps {
  service: Service;
  details: BookingDetails;
  quote: Quote;
  onConfirm: () => void;
  t: any;
}

const QuoteView: React.FC<QuoteViewProps> = ({ service, details, quote, onConfirm, t }) => {
  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in bg-white p-8 rounded-lg shadow-md border border-gray-200">
      <h2 className="text-3xl font-bold text-black mb-2 text-center">{t.quote.title}</h2>
      <p className="text-gray-600 mb-6 text-center">{t.quote.subtitle}</p>
      
      <div className="space-y-4 mb-8 text-sm">
        <div className="p-4 bg-gray-50 rounded-md border">
            <p className="font-semibold text-gray-500 uppercase text-xs tracking-wider">{t.quote.service}</p>
            <p className="font-bold text-lg text-black">{t.services[service.id].name}</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-md border">
            <p className="font-semibold text-gray-500 uppercase text-xs tracking-wider">{t.quote.whenWhere}</p>
            <p className="text-gray-800 font-medium">{new Date(details.date).toDateString()} at {details.time}</p>
            <p className="text-gray-800">{details.location}</p>
        </div>
      </div>
      
      <div className="text-center mb-8">
        <p className="text-gray-500 uppercase tracking-wider">{t.quote.totalPrice}</p>
        <p className="text-5xl font-extrabold text-black">{quote.price} DH</p>
        <p className="text-gray-600 mt-1">{t.quote.timeframe}: {quote.timeframe}</p>
      </div>

      <div className="text-left my-8 p-4 bg-gray-100 border-l-4 border-gray-800">
        <h3 className="font-bold text-lg text-black mb-2">{t.quote.depositTitle}</h3>
        <p className="text-gray-700 mb-3">{t.quote.depositInstructions}</p>
        <div className="bg-white p-3 rounded-md border text-center">
            <p className="text-sm text-gray-500 uppercase tracking-wider">{t.quote.ribLabel}</p>
            <p className="font-mono text-lg font-bold text-black tracking-widest">{t.quote.ribNumber}</p>
        </div>
      </div>

      <button onClick={onConfirm} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-sm font-bold text-white bg-gray-800 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black transition-colors duration-200">
        {t.quote.confirmButton}
      </button>
    </div>
  );
};

export default QuoteView;