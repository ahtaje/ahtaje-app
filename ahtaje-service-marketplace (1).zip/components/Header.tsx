
import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';

interface HeaderProps {
  onShowProfile: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: { language: string };
}

const Logo: React.FC = () => (
  <svg 
    viewBox="0 0 160 60" 
    className="h-10 md:h-12 w-auto fill-current text-black" 
    xmlns="http://www.w3.org/2000/svg"
    aria-label="AHTAJE Logo"
  >
    {/* A */}
    <path d="M0 0h40v60H0V0zm15 15h10v15H15V15z" />
    <rect x="15" y="45" width="10" height="15" fill="white" />
    
    {/* H */}
    <path d="M50 0h15v22h10V0h15v60H75V38H65v22H50V0z" />
    
    {/* T */}
    <path d="M100 0h60v15h-22v45h-15V15h-23V0z" />
  </svg>
);

const Header: React.FC<HeaderProps> = ({ onShowProfile, language, setLanguage, t }) => {
  const [isLangDropdownOpen, setLangDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    setLangDropdownOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setLangDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="relative w-full max-w-4xl mx-auto flex items-center justify-between p-4 h-24">
        <div className="flex-1 flex justify-start">
            <div className="relative" ref={dropdownRef}>
                <button 
                    onClick={() => setLangDropdownOpen(!isLangDropdownOpen)}
                    className="font-bold text-lg text-gray-800 hover:text-black transition-colors"
                >
                    {t.language}
                </button>
                {isLangDropdownOpen && (
                    <div className="absolute top-full mt-2 w-24 bg-white rounded-md shadow-lg border z-20">
                        <button onClick={() => handleLanguageChange('en')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">EN</button>
                        <button onClick={() => handleLanguageChange('fr')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">FR</button>
                        <button onClick={() => handleLanguageChange('ar')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">AR</button>
                    </div>
                )}
            </div>
        </div>
        
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 cursor-pointer hover:opacity-80 transition-opacity">
            <Logo />
        </div>
        
        <div className="flex-1 flex justify-end items-center">
            <button onClick={onShowProfile} className="text-gray-500 hover:text-black transition-colors" aria-label="User Profile">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-9 w-9" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
            </button>
        </div>
    </header>
  );
};

export default Header;
