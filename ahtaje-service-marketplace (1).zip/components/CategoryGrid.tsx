import React from 'react';
import { ServiceCategory } from '../types';
import CategoryCard from './CategoryCard';

interface CategoryGridProps {
  categories: ServiceCategory[];
  onSelectCategory: (category: ServiceCategory) => void;
  t: { [key: string]: string[] };
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ categories, onSelectCategory, t }) => {
  return (
    <div className="grid grid-cols-3 gap-4 sm:gap-6 mt-4">
      {categories.map((category) => (
        <CategoryCard key={category.id} category={category} onSelect={onSelectCategory} name={t[category.id]}/>
      ))}
    </div>
  );
};

export default CategoryGrid;
