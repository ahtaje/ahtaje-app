import React from 'react';

interface FooterProps {
    onCustomRequest: () => void;
    t: {
        contact: string;
        location: string;
    }
}

const Footer: React.FC<FooterProps> = ({ onCustomRequest, t }) => {
  return (
    <footer className="text-center py-8 mt-auto px-4">
      <button 
        onClick={onCustomRequest}
        className="bg-gray-200 text-gray-500 rounded-full px-10 py-4 w-full max-w-lg mx-auto mb-6 text-sm font-medium tracking-widest uppercase hover:bg-gray-300 transition-colors duration-200">
        {t.contact}
      </button>
      <p className="text-gray-400 text-sm font-medium tracking-wider">{t.location}</p>
    </footer>
  );
};

export default Footer;