import React, { useState, useEffect } from 'react';
import { Service } from '../types';

interface TrackingViewProps {
    service: Service;
    onReset: () => void;
}

const STATUSES = [
    "Booking Confirmed",
    "Provider Assigned",
    "Provider is on the way",
    "Service in Progress",
    "Completed"
];

const TrackingView: React.FC<TrackingViewProps> = ({ service, onReset }) => {
  const [currentStatusIndex, setCurrentStatusIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStatusIndex(prevIndex => {
        if (prevIndex < STATUSES.length - 1) {
          return prevIndex + 1;
        }
        clearInterval(interval);
        return prevIndex;
      });
    }, 3000); // Update status every 3 seconds

    return () => clearInterval(interval);
  }, []);
  
  const isCompleted = currentStatusIndex === STATUSES.length - 1;

  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in">
        <div className="bg-gray-50 p-8 rounded-lg border border-gray-200">
            <h2 className="text-3xl font-bold text-black mb-2 text-center">Track Your Service</h2>
            <p className="text-gray-600 mb-8 text-center">You can see the live status of your <span className="font-semibold">{service.name}</span> request below.</p>

            <div className="relative pl-8">
                {/* Vertical line */}
                <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-gray-200"></div>

                {STATUSES.map((status, index) => {
                    const isActive = index <= currentStatusIndex;
                    const isCurrent = index === currentStatusIndex;
                    return (
                        <div key={status} className="mb-8 relative">
                            <div className={`absolute left-[-1.1rem] top-1.5 w-4 h-4 rounded-full ${isActive ? 'bg-black' : 'bg-gray-300'}`}>
                                {isCurrent && !isCompleted && <div className="absolute inset-0 bg-black rounded-full animate-ping"></div>}
                            </div>
                            <p className={`font-bold ${isActive ? 'text-black' : 'text-gray-400'}`}>{status}</p>
                            {isActive && <p className="text-sm text-gray-500">Update received</p>}
                        </div>
                    );
                })}
            </div>
        </div>
        
        {isCompleted && (
            <div className="text-center mt-8 animate-fade-in">
                 <h3 className="text-2xl font-bold text-green-600">Service Completed!</h3>
                 <p className="text-gray-700 mt-2 mb-6">We hope you are satisfied with the service. Please leave a review!</p>
                <button onClick={onReset} className="bg-gray-200 text-gray-700 rounded-full px-8 py-3 text-sm font-medium hover:bg-gray-300 transition-colors duration-200">
                    Start a New Request
                </button>
            </div>
        )}
    </div>
  );
};

export default TrackingView;
