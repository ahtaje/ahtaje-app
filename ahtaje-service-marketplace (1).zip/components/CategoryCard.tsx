import React from 'react';
import { ServiceCategory } from '../types';

interface CategoryCardProps {
  category: ServiceCategory;
  onSelect: (category: ServiceCategory) => void;
  name: string[];
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category, onSelect, name }) => {
  return (
    <div
      className="bg-gray-700 aspect-[3/4] rounded-t-[4rem] rounded-b-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transform transition-all duration-300 hover:bg-black hover:-translate-y-1"
      onClick={() => onSelect(category)}
    >
      <h2 className="text-lg sm:text-xl font-bold text-white leading-tight">
        {name.map((line, index) => (
            <span key={index} className="block">{line}</span>
        ))}
      </h2>
    </div>
  );
};

export default CategoryCard;
