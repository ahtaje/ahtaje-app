import React from 'react';

const SearchBar: React.FC = () => {
  return (
    <div className="w-full mb-8">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        <input
          type="text"
          placeholder="Looking for something else?"
          className="w-full bg-white border border-gray-200 rounded-full py-3 pl-12 pr-12 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#0057A7] transition"
        />
        <div className="absolute inset-y-0 right-0 pr-4 flex items-center">
          <button className="text-gray-500 hover:text-[#0057A7]" aria-label="Voice search">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm5 10.5a.5.5 0 01.5.5v.5a.5.5 0 01-1 0V15a.5.5 0 01.5-.5zM8 15a.5.5 0 00-.5.5v.5a.5.5 0 001 0V15A.5.5 0 008 15zm-2-1.5A.5.5 0 016 14v.5a.5.5 0 01-1 0V14a.5.5 0 01.5-.5zm8 0a.5.5 0 01.5.5v.5a.5.5 0 01-1 0V14a.5.5 0 01.5-.5z" clipRule="evenodd" />
                <path d="M10 18a5 5 0 005-5h-1a4 4 0 01-8 0H4a5 5 0 005 5z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
