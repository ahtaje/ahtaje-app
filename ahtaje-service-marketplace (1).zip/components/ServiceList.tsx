import React from 'react';
import { Service, ServiceCategory } from '../types';

interface ServiceListProps {
  category: ServiceCategory;
  onBack: () => void;
  onSelectService: (service: Service) => void;
  t: any;
}

const ServiceList: React.FC<ServiceListProps> = ({ category, onBack, onSelectService, t }) => {
  const categoryName = t.categories[category.id].join(' ');
  return (
    <div className="w-full max-w-2xl mx-auto animate-fade-in">
      <button
        onClick={onBack}
        className="mb-6 text-gray-600 hover:text-black transition-colors duration-200 flex items-center group"
        aria-label={t.serviceList.back}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-2 transition-transform duration-200 group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
        </svg>
        {t.serviceList.back}
      </button>
      <h2 className="text-3xl md:text-4xl font-bold text-black mb-8 text-center">{categoryName}</h2>
      <div className="space-y-4">
        {category.services.map((service) => (
          <div key={service.id} className="bg-white border border-gray-200 rounded-lg p-4 flex justify-between items-center transition-shadow hover:shadow-md">
            <div className="flex-1 pr-4">
              <h3 className="font-bold text-lg text-gray-800">{t.services[service.id].name}</h3>
              <p className="text-gray-600 text-sm">{t.services[service.id].description}</p>
            </div>
            <button 
                onClick={() => onSelectService(service)}
                className="bg-gray-800 text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-black transition-colors duration-200 flex-shrink-0"
            >
                {t.serviceList.request}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceList;
