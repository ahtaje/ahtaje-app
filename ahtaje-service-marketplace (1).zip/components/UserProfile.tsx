import React from 'react';

interface UserProfileProps {
  onBack: () => void;
  isLoggedIn: boolean;
  onLogin: () => void;
  onLogout: () => void;
  t: {
      back: string;
      title: string;
      totalOrders: string;
      loginTitle: string;
      emailLabel: string;
      passwordLabel: string;
      loginButton: string;
      logoutButton: string;
      or: string;
      google: string;
      facebook: string;
  }
}

const UserProfile: React.FC<UserProfileProps> = ({ onBack, isLoggedIn, onLogin, onLogout, t }) => {
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };
    
  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in">
        <button
            onClick={onBack}
            className="mb-6 text-gray-600 hover:text-black transition-colors duration-200 flex items-center group"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-2 transition-transform duration-200 group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
            {t.back}
        </button>

        <div className="bg-white p-8 rounded-lg shadow-md border border-gray-200">
            <div className="text-center mb-8">
                <img
                    className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-gray-200"
                    src="https://picsum.photos/200"
                    alt="User profile"
                />
                <h2 className="text-2xl font-bold text-black">User Name</h2>
                <p className="text-gray-500">user.name@example.com</p>
            </div>
            
            <div className="text-center bg-gray-100 p-4 rounded-lg mb-8">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">{t.totalOrders}</p>
                <p className="text-3xl font-bold text-black">12</p>
            </div>

            {isLoggedIn ? (
                <button 
                    onClick={onLogout}
                    className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-sm font-bold text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors duration-200">
                    {t.logoutButton}
                </button>
            ) : (
                <div>
                    <h3 className="text-xl font-bold text-center mb-6">{t.loginTitle}</h3>
                    <form onSubmit={handleLoginSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700" htmlFor="email">{t.emailLabel}</label>
                            <input className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-gray-500 focus:border-gray-500" type="email" id="email" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700" htmlFor="password">{t.passwordLabel}</label>
                            <input className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-gray-500 focus:border-gray-500" type="password" id="password" />
                        </div>
                        <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-sm font-bold text-white bg-gray-800 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black transition-colors duration-200">
                            {t.loginButton}
                        </button>
                    </form>

                    <div className="my-6 flex items-center justify-center">
                        <div className="flex-grow border-t border-gray-300"></div>
                        <span className="flex-shrink mx-4 text-sm text-gray-500">{t.or}</span>
                        <div className="flex-grow border-t border-gray-300"></div>
                    </div>

                    <div className="space-y-3">
                        <button className="w-full flex items-center justify-center py-2.5 px-4 border border-gray-300 rounded-full shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                            <svg className="w-5 h-5 mr-2" viewBox="0 0 48 48" width="48px" height="48px"><path fill="#fbc02d" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12	s5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24s8.955,20,20,20	s20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path><path fill="#e53935" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039	l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path><path fill="#4caf50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36	c-5.222,0-9.521-3.108-11.127-7.481l-6.571,4.819C9.656,39.663,16.318,44,24,44z"></path><path fill="#1565c0" d="M43.611,20.083L43.595,20L42,20H24v8h11.303c-0.792,2.447-2.275,4.481-4.16,5.894	l6.19,5.238C39.712,34.464,44,28.756,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path></svg>
                            {t.google}
                        </button>
                        <button className="w-full flex items-center justify-center py-2.5 px-4 border border-gray-300 rounded-full shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                            <svg className="w-5 h-5 mr-2" fill="#1877F2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M22,12c0-5.52,4.48-10,10-10S2,6.48,2,12c0,4.84,3.44,8.87,8,9.8V15H8v-3h2V9.5C10,7.57,11.57,6,13.5,6H16v3h-1.5 C14.12,9,14,9.12,14,9.5V12h2.5l-0.5,3H14v6.8C18.56,20.87,22,16.84,22,12z"></path></svg>
                            {t.facebook}
                        </button>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default UserProfile;