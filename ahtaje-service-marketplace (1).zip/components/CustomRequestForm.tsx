import React, { useState, ChangeEvent, FormEvent } from 'react';
import { BookingDetails } from '../types';

interface CustomRequestFormProps {
  onBack: () => void;
  onSubmit: (details: BookingDetails) => void;
  t: {
    back: string;
    title: string;
    subtitle: string;
    notesLabel: string;
    notesPlaceholder: string;
    photoLabel: string;
    photoButton: string;
    submit: string;
  };
}

const CustomRequestForm: React.FC<CustomRequestFormProps> = ({ onBack, onSubmit, t }) => {
  const [details, setDetails] = useState<BookingDetails>({
    location: '', // Custom requests might not need these, but keeping for type consistency
    date: '',
    time: '',
    notes: '',
  });

  const handleChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setDetails(prev => ({
        ...prev,
        photo: file,
        photoPreview: URL.createObjectURL(file),
      }));
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    // For custom requests, location/date/time aren't in the form, so we submit with just notes/photo
    onSubmit({
        location: 'N/A',
        date: 'N/A',
        time: 'N/A',
        notes: details.notes,
        photo: details.photo,
        photoPreview: details.photoPreview
    });
  };

  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in bg-white p-8 rounded-lg shadow-md border">
      <button onClick={onBack} className="mb-6 text-gray-600 hover:text-black transition-colors duration-200 flex items-center group">
        <svg xmlns="http://www.w.org/2000/svg" className="h-5 w-5 mx-2 transition-transform duration-200 group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
        </svg>
        {t.back}
      </button>

      <h2 className="text-3xl font-bold text-black mb-2 text-center">{t.title}</h2>
      <p className="text-gray-600 mb-8 text-center">{t.subtitle}</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700">{t.notesLabel}</label>
          <textarea name="notes" id="notes" required value={details.notes} onChange={handleChange} rows={6} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder={t.notesPlaceholder}></textarea>
        </div>

        <div>
            <label className="block text-sm font-medium text-gray-700">{t.photoLabel}</label>
            <div className="mt-1 flex items-center space-x-4">
                <label htmlFor="photo" className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    <span>{t.photoButton}</span>
                    <input id="photo" name="photo" type="file" className="sr-only" onChange={handlePhotoChange} accept="image/*" />
                </label>
                {details.photoPreview && (
                    <img src={details.photoPreview} alt="Preview" className="h-16 w-16 rounded-md object-cover" />
                )}
            </div>
        </div>

        <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-sm font-bold text-white bg-gray-800 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black transition-colors duration-200">
          {t.submit}
        </button>
      </form>
    </div>
  );
};

export default CustomRequestForm;