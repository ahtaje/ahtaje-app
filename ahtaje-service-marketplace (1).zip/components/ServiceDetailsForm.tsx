import React, { useState, ChangeEvent, FormEvent } from 'react';
import { Service, BookingDetails } from '../types';

interface ServiceDetailsFormProps {
  service: Service;
  onBack: () => void;
  onSubmit: (details: BookingDetails) => void;
  t: any;
}

const ServiceDetailsForm: React.FC<ServiceDetailsFormProps> = ({ service, onBack, onSubmit, t }) => {
  const [details, setDetails] = useState<BookingDetails>({
    location: '',
    date: '',
    time: '',
    notes: '',
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setDetails(prev => ({
        ...prev,
        photo: file,
        photoPreview: URL.createObjectURL(file),
      }));
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit(details);
  };

  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in bg-white p-8 rounded-lg shadow-md border">
      <button onClick={onBack} className="mb-6 text-gray-600 hover:text-black transition-colors duration-200 flex items-center group">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-2 transition-transform duration-200 group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
        </svg>
        {t.detailsForm.back}
      </button>

      <h2 className="text-3xl font-bold text-black mb-2 text-center">{t.services[service.id].name}</h2>
      <p className="text-gray-600 mb-8 text-center">{t.detailsForm.title}</p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700">{t.detailsForm.locationLabel}</label>
          <input type="text" name="location" id="location" required value={details.location} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder={t.detailsForm.locationPlaceholder} />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700">{t.detailsForm.dateLabel}</label>
                <input type="date" name="date" id="date" required value={details.date} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" />
            </div>
            <div>
                <label htmlFor="time" className="block text-sm font-medium text-gray-700">{t.detailsForm.timeLabel}</label>
                <input type="time" name="time" id="time" required value={details.time} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" />
            </div>
        </div>
        
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700">{t.detailsForm.notesLabel}</label>
          <textarea name="notes" id="notes" value={details.notes} onChange={handleChange} rows={4} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder={t.detailsForm.notesPlaceholder}></textarea>
        </div>

        <div>
            <label className="block text-sm font-medium text-gray-700">{t.detailsForm.photoLabel}</label>
            <div className="mt-1 flex items-center space-x-4">
                <label htmlFor="photo" className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    <span>{t.detailsForm.photoButton}</span>
                    <input id="photo" name="photo" type="file" className="sr-only" onChange={handlePhotoChange} accept="image/*" />
                </label>
                {details.photoPreview && (
                    <img src={details.photoPreview} alt="Preview" className="h-16 w-16 rounded-md object-cover" />
                )}
            </div>
        </div>

        <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-sm font-bold text-white bg-gray-800 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black transition-colors duration-200">
          {t.detailsForm.submit}
        </button>
      </form>
    </div>
  );
};

export default ServiceDetailsForm;
