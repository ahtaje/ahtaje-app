import React from 'react';

interface ProcessingViewProps {
    t: {
        title: string;
        subtitle: string;
    }
}

const ProcessingView: React.FC<ProcessingViewProps> = ({ t }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full animate-fade-in py-16">
      <div className="w-12 h-12 border-4 border-gray-200 border-t-gray-800 rounded-full animate-spin mb-6"></div>
      <h2 className="text-2xl font-bold text-black">{t.title}</h2>
      <p className="text-gray-600 mt-2">{t.subtitle}</p>
    </div>
  );
};

export default ProcessingView;
